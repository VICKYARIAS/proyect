
#ARIAS RAMIREZ VICTORIA ANGÉLICA
import sys
from CuentaDeCredito import*
from CuentaDeAhorro import*
from Cuenta import*
from Cliente import*

class MenuCuenta:

  def __init__ (self):
    
    self.opciones={

      "1": self.AgregarunaCuenta,
      "2": self.retirar,
      "3": self.depositar,
      "4": self.salir
    }

  def MostrarMenu(self):
    print (""" 
    **********Bienvenido*********
    
    Este es el menú:
    1 Agregue una cuenta
    2 Retirar
    3 Depositar
    4 Salir""")
  #Éste método muestra el menú y responde a las elecciones
  def Correr(self):
    
    while True:
      self.MostrarMenu()

      opcion= input("\nEliga una opciòn:")

      accion= self.opciones.get(opcion)

      if accion:
         accion()
      else:
        print("\n{0} no es una opción válida" "\n\nElija otro opción".format(opcion))
  
  def retirar(self):

    cantidad= input("¿Qué cantidad desea reitrar?")
    self.Cuenta.retirar(int(cantidad))

  def depositar(self):

    cantidad= input("\n¿Qué cantidad desea depositar?")
    self.Cuenta.depositar(int(cantidad))
  
  def salir(self):
    print("\n\n\t***Gracias por su preferencia, hasta luego.***")
    sys.exit(0)
    

  def AgregarunaCuenta(self):

    msg="\nEligió agregar una cuenta "
    msg+="\n\nTipos de cuenta"
    msg+="\n1. Cuenta de Ahorro"
    msg+="\n2.Cuenta de Crédito"
    print(msg)
    tipo=input("\nElija el tipo de cuenta:")
    cuentas=[]
    if int(tipo)==1:
      print("\nPara crear la Cuenta de Ahorro inserte los siguientes datos: "+ "\n" )
      SaldoInicial=int(input("\nSaldo inicial: $ " ))
      TasadeInteres=int(input("Tasa de interés:"))
      Tipo="Cuenta de Ahorro"

      print("\nCUENTA REGISTRADA\n")
      print("Datos de la cuenta: \n ")
      cuenta=CuentaDeAhorro(SaldoInicial,TasadeInteres,Tipo)
      print(cuenta)
      

    else:
      print("\nPara crear la Cuenta de Crédito inserte los siguientes datos: "+ "\n" )
      SaldoInicial=int(input("\nSaldo inicial: $ " ))
      TasadeInteres=int(input("Tasa de interés:"))
      Sobregiro=int(input("Sobregiro: $ "))
      Tipo="Cuenta de Crédito"
      cuenta=CuentaDeCredito(SaldoInicial, Sobregiro,TasadeInteres,Tipo)
      print("\nCUENTA REGISTRADA\n")
      print("Datos de la cuenta: \n ")
      print(cuenta)

  #NO pude agregar el método Cliente.AñadirCuenta porque me marcaba el error de que tenía no estaba recibiendo niguna cuenta aunque sí lo hacía y como la cuenta no la pospia agregar no podía utlizar los métods de retirar y depositar
